using InventoryManagement.Models;
using Microsoft.Data.SqlClient;

namespace InventoryManagement.Data
{
    // All ADO.NET code lives here: SqlConnection, SqlCommand, SqlDataReader, parameters
    public class ProductRepository
    {
        private readonly string _connStr;

        public ProductRepository(IConfiguration config)
        {
            _connStr = config.GetConnectionString("InventoryDb");
        }

        // ---------- READ (all, with optional search) ----------
        public List<Product> GetAll(string search = null)
        {
            var list = new List<Product>();
            const string sql = @"SELECT ProductId, ProductName, Category, Quantity, UnitPrice, ReorderLevel, CreatedOn
                                 FROM dbo.Products
                                 WHERE (@s IS NULL OR ProductName LIKE '%' + @s + '%' OR Category LIKE '%' + @s + '%')
                                 ORDER BY ProductName";

            using (var con = new SqlConnection(_connStr))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@s", string.IsNullOrWhiteSpace(search) ? DBNull.Value : search.Trim());
                con.Open();
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                        list.Add(Map(rd));
                }
            }
            return list;
        }

        // ---------- READ (one) ----------
        public Product GetById(int id)
        {
            const string sql = @"SELECT ProductId, ProductName, Category, Quantity, UnitPrice, ReorderLevel, CreatedOn
                                 FROM dbo.Products WHERE ProductId = @id";
            using (var con = new SqlConnection(_connStr))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                using (var rd = cmd.ExecuteReader())
                    return rd.Read() ? Map(rd) : null;
            }
        }

        // ---------- CREATE ----------
        public int Insert(Product p)
        {
            const string sql = @"INSERT INTO dbo.Products (ProductName, Category, Quantity, UnitPrice, ReorderLevel)
                                 VALUES (@n, @c, @q, @u, @r);
                                 SELECT CAST(SCOPE_IDENTITY() AS INT);";
            using (var con = new SqlConnection(_connStr))
            using (var cmd = new SqlCommand(sql, con))
            {
                AddParams(cmd, p);
                con.Open();
                return (int)cmd.ExecuteScalar();          // returns the new identity id
            }
        }

        // ---------- UPDATE ----------
        public bool Update(Product p)
        {
            const string sql = @"UPDATE dbo.Products
                                 SET ProductName=@n, Category=@c, Quantity=@q, UnitPrice=@u, ReorderLevel=@r
                                 WHERE ProductId=@id";
            using (var con = new SqlConnection(_connStr))
            using (var cmd = new SqlCommand(sql, con))
            {
                AddParams(cmd, p);
                cmd.Parameters.AddWithValue("@id", p.ProductId);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;         // rows affected
            }
        }

        // ---------- DELETE ----------
        public bool Delete(int id)
        {
            const string sql = "DELETE FROM dbo.Products WHERE ProductId = @id";
            using (var con = new SqlConnection(_connStr))
            using (var cmd = new SqlCommand(sql, con))
            {
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        // ---------- helpers ----------
        private static void AddParams(SqlCommand cmd, Product p)
        {
            cmd.Parameters.AddWithValue("@n", p.ProductName);
            cmd.Parameters.AddWithValue("@c", p.Category);
            cmd.Parameters.AddWithValue("@q", p.Quantity);
            cmd.Parameters.AddWithValue("@u", p.UnitPrice);
            cmd.Parameters.AddWithValue("@r", p.ReorderLevel);
        }

        private static Product Map(SqlDataReader rd) => new Product
        {
            ProductId = rd.GetInt32(0),
            ProductName = rd.GetString(1),
            Category = rd.GetString(2),
            Quantity = rd.GetInt32(3),
            UnitPrice = rd.GetDecimal(4),
            ReorderLevel = rd.GetInt32(5),
            CreatedOn = rd.GetDateTime(6)
        };
    }
}
