using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Product name is required")]
        [StringLength(100)]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Category is required")]
        public string Category { get; set; }

        [Range(0, 100000, ErrorMessage = "Quantity must be 0 or more")]
        public int Quantity { get; set; }

        [Range(0.01, 10000000, ErrorMessage = "Price must be greater than 0")]
        [Display(Name = "Unit Price")]
        public decimal UnitPrice { get; set; }

        [Range(0, 100000)]
        [Display(Name = "Reorder Level")]
        public int ReorderLevel { get; set; } = 10;

        public DateTime CreatedOn { get; set; }

        public decimal StockValue => Quantity * UnitPrice;
        public bool IsLowStock => Quantity <= ReorderLevel;
    }
}
