USE InventoryDB;
GO

IF OBJECT_ID(N'dbo.Products', N'U') IS NOT NULL
    DROP TABLE dbo.Products;
GO

CREATE TABLE dbo.Products
(
    ProductId    INT IDENTITY(1,1) PRIMARY KEY,
    ProductName  NVARCHAR(100)  NOT NULL,
    Category     NVARCHAR(50)   NOT NULL,
    Quantity     INT            NOT NULL CHECK (Quantity >= 0),
    UnitPrice    DECIMAL(10,2)  NOT NULL CHECK (UnitPrice > 0),
    ReorderLevel INT            NOT NULL DEFAULT 10,
    CreatedOn    DATETIME       NOT NULL DEFAULT GETDATE()
);
GO

INSERT INTO dbo.Products (ProductName, Category, Quantity, UnitPrice, ReorderLevel) VALUES
('A4 Notebook',        'Stationery', 150,   45.00, 30),
('Ball Pen (Blue)',    'Stationery', 400,   10.00, 100),
('USB Keyboard',       'Electronics', 25, 599.00, 10),
('Optical Mouse',      'Electronics',  8, 349.00, 10),
('Office Chair',       'Furniture',   12, 3499.00, 5),
('LED Table Lamp',     'Electronics', 40, 799.00, 10);
GO

SELECT * FROM dbo.Products;
GO
