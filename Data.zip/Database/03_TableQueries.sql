USE InventoryDB;
GO
-- READ
SELECT * FROM dbo.Products ORDER BY ProductName;
-- CREATE
INSERT INTO dbo.Products (ProductName, Category, Quantity, UnitPrice, ReorderLevel)
VALUES ('Stapler', 'Stationery', 60, 120.00, 15);
-- UPDATE
UPDATE dbo.Products SET Quantity = Quantity + 20 WHERE ProductName = 'Optical Mouse';
-- DELETE
DELETE FROM dbo.Products WHERE ProductName = 'Stapler';
-- Reports
SELECT Category, COUNT(*) AS Items, SUM(Quantity * UnitPrice) AS StockValue
FROM dbo.Products GROUP BY Category;
SELECT * FROM dbo.Products WHERE Quantity <= ReorderLevel;   -- low stock
GO
