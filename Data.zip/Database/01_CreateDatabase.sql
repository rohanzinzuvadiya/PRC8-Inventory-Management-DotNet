-- Run in SSMS or Visual Studio > SQL Server Object Explorer > New Query
USE master;
GO
IF DB_ID(N'InventoryDB') IS NULL
    CREATE DATABASE InventoryDB;
GO
USE InventoryDB;
GO
