using InventoryManagement.Data;
using InventoryManagement.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryManagement.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductRepository _repo;
        public ProductsController(ProductRepository repo) { _repo = repo; }

        public IActionResult Index(string search)
        {
            try
            {
                var list = _repo.GetAll(search);
                ViewBag.Search = search;
                ViewBag.TotalItems = list.Count;
                ViewBag.TotalValue = list.Sum(p => p.StockValue);
                ViewBag.LowStock = list.Count(p => p.IsLowStock);
                return View(list);
            }
            catch (Exception ex)
            {
                ViewBag.DbError = "Could not read from the database: " + ex.Message;
                return View(new List<Product>());
            }
        }

        [HttpGet]
        public IActionResult Create() => View(new Product());

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(Product p)
        {
            if (!ModelState.IsValid) return View(p);
            _repo.Insert(p);
            TempData["Msg"] = "Product added successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var p = _repo.GetById(id);
            return p == null ? NotFound() : View(p);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(Product p)
        {
            if (!ModelState.IsValid) return View(p);
            _repo.Update(p);
            TempData["Msg"] = "Product updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var p = _repo.GetById(id);
            return p == null ? NotFound() : View(p);
        }

        [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _repo.Delete(id);
            TempData["Msg"] = "Product deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
